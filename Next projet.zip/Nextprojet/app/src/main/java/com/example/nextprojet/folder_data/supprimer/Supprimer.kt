package com.example.nextprojet.folder_data.supprimer

data class Supprimer(
    val id: String
)