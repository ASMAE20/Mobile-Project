package com.example.nextprojet





import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.example.nextprojet.repository.Poste_Repository


// deleting post with deletePost method

class SupprimerPoste : AppCompatActivity() {
    //init
    private lateinit var viewModel: MainViewModel


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.supprimer_post)
        // activity on intent
        Intent
    }
    private val Intent: Unit
        private get() {
            if (intent.hasExtra("post_id")) {

                // collecting data from longClicked post
                val postId = intent.getStringExtra("post_id")

                // init warning message
                val warning: TextView = findViewById<View>(R.id.successText) as TextView
                val warningText = "le poste avec id  : $postId est bien supprimé"

                // sending post delete warning
                warning.setText(warningText)

                // forward
                if (postId != null) {
                    supprimer(postId)
                }
            }
        }



    private fun supprimer(postId: String) {
        // forward with deletePost
        val repository = Poste_Repository()
        val viewModelFactory = MainViewModelFactory(repository)
        viewModel = ViewModelProvider(this, viewModelFactory).get(MainViewModel::class.java)
        viewModel.supprimerPoste(postId)
    }
}