package com.example.nextprojet
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity


class PosteCréer : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.poste_creer)

        //activity to show that post was called with success
    }
}