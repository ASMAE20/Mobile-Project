package com.example.nextprojet.folder_adapter

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.nextprojet.R
import com.example.nextprojet.PosteBytag

import com.example.nextprojet.folder_data.main.PostData
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.post_layout.view.*


// same as MyAdapter but DataType modified
class PostAdapter: RecyclerView.Adapter<PostAdapter.MyViewHolder>(){
    // init
    private val TAG = "PostRecyclerViewAdapter"
    private var Context: Context? = null
    private var Layout = R.layout.row_layout
    private var Post= emptyList<PostData>()

    inner class MyViewHolder(itemView: View): RecyclerView.ViewHolder(itemView)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        return MyViewHolder(LayoutInflater.from(parent.context).inflate(Layout, parent, false))
    }

    override fun getItemCount(): Int {
        return Post.size
    }



    override fun onBindViewHolder(holder: MyViewHolder, i: Int) {
        // title
        holder.itemView.authName.text = String.format("%s. %s %s", Post[i].owner.title, Post[i].owner.firstName, Post[i].owner.lastName )
        // Date
        holder.itemView.Date.text = Post[i].publishDate
        // avatar
        Picasso.get().load(Post[i].owner.picture).into(holder.itemView.avatar);
        // image
        Picasso.get().load(Post[i].image).into(holder.itemView.mainImage);
        // content
        holder.itemView.content.text = Post[i].text
        // tags
        holder.itemView.tag1.text = Post[i].tags[0]
        holder.itemView.tag2.text = Post[i].tags[1]
        holder.itemView.tag3.text = Post[i].tags[2]
        // there is no on post click listener
        // go to posts by tag
        holder.itemView.tag1.setOnClickListener {
            val tag = it.tag1.text
            val intent = Intent(Context, PosteBytag::class.java)
            intent.putExtra("tag", tag)
            Context?.startActivity(intent)
        }
        holder.itemView.tag2.setOnClickListener {
            val tag = it.tag2.text
            val intent = Intent(Context, PosteBytag::class.java)
            intent.putExtra("tag", tag)
            Context?.startActivity(intent)
        }
        holder.itemView.tag3.setOnClickListener {
            val tag = it.tag3.text
            val intent = Intent(Context, PosteBytag::class.java)
            intent.putExtra("tag", tag)
            Context?.startActivity(intent)
        }
    }

    // update / set data
    fun setPostData(context: Context, layout: Int, Post: List<PostData>){
        this.Post = Post
        Context = context
        Layout = layout
        notifyDataSetChanged()
    }




}