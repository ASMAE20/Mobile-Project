package com.example.nextprojet.tools

class Global {
    companion object {
        const val web_site = "https://dummyapi.io/data/v1/"
        const val debut_page = 0
        const val nbr_page = 5
    }
}