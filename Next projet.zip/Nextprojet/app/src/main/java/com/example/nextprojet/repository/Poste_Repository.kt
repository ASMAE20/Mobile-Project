package com.example.nextprojet.repository






import com.example.nextprojet.folder_api.Retrofit
import com.example.nextprojet.folder_data.supprimer.Supprimer
import com.example.nextprojet.folder_data.main.PostPreview
import com.example.nextprojet.folder_data.main.PostData
import com.example.nextprojet.folder_data.main.DataResponse
import retrofit2.Response

// init return of Response after the api call
class Poste_Repository {

    suspend fun AfficherPosts(pageNumber: Int, postsNumber: Int): Response<DataResponse> {
        return Retrofit.api.AfficherPosts(pageNumber, postsNumber)
    }

    suspend fun afficherPost(postId: String): Response<PostData> {
        return Retrofit.api.afficherPost(postId)
    }

    suspend fun afficher_by_tag(tag: String, postsNumber: Int): Response<DataResponse> {
        return Retrofit.api.afficher_by_tag(tag, postsNumber)
    }

    suspend fun supprimerPoste(postId: String): Response<Supprimer> {
        return Retrofit.api.supprimerPoste(postId)
    }

    suspend fun creerPoste(text: String, image: String, likes: Int, tags: ArrayList<String>, owner: String): Response<PostPreview> {
        return Retrofit.api.creerPoste(text, image,likes, tags ,owner)
    }
}