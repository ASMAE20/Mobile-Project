package com.example.nextprojet.folder_api




import com.example.nextprojet.folder_data.supprimer.Supprimer
import com.example.nextprojet.folder_data.main.PostPreview
import com.example.nextprojet.folder_data.main.PostData
import com.example.nextprojet.folder_data.main.DataResponse
import retrofit2.Response
import retrofit2.http.*

// setting up all kinds of callouts

interface PosteService {
    @Headers("app-id: 623c2f76f3148f34f18ed59b")
    @GET("post")

    suspend fun AfficherPosts(
        @Query("page") pageNumber: Int,
        @Query("limit") postsNumber: Int
    ): Response<DataResponse>

    @Headers("app-id: 623c2f76f3148f34f18ed59b")
    @GET("post/{post}")
    suspend fun afficherPost(
        @Path("post") postId: String
    ): Response<PostData>

    @Headers("app-id: 623c2f76f3148f34f18ed59b")
    @GET("tag/{tag}/post")
    suspend fun afficher_by_tag(
        @Path("tag") tag: String,
        @Query("limit") postsNumber: Int
    ): Response<DataResponse>

    @Headers("app-id: 623c2f76f3148f34f18ed59b")
    @DELETE("post/{post}")
    suspend fun supprimerPoste(
        @Path("post") postId: String
    ): Response<Supprimer>

    @FormUrlEncoded
    @Headers("app-id: 623c2f76f3148f34f18ed59b")
    @POST("post/create")
    suspend fun creerPoste(
        @Field("text") text: String,
        @Field("image") image: String,
        @Field("likes") likes: Int,
        @Field("tags") tags: ArrayList<String>,
        @Field("owner") owner: String,
    ): Response<PostPreview>

}




