package com.example.nextprojet

import com.example.nextprojet.folder_adapter.Adapter
import com.example.nextprojet.repository.Poste_Repository
import com.example.nextprojet.tools.Global.Companion.debut_page
import com.example.nextprojet.tools.Global.Companion.nbr_page

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

import kotlinx.android.synthetic.main.activity_main.*

/* Main Activity:
    -button to start CreatePostActivity
    -posts called with retrofit in main activity's view model
    -infinite scroll posts
 */
open class MainActivity : AppCompatActivity() {
    //init
    private lateinit var viewModel: MainViewModel
    private val myAdapter by lazy { Adapter() }
    lateinit var layoutManager: LinearLayoutManager
    var loading = false
    var call = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        setupRecyclerview()

        // go to CreatePostActivity after button click
        PostButton.setOnClickListener {
            val intent = Intent(this, CréerPoste::class.java)
            this.startActivity(intent)
        }

        // init layout
        layoutManager = LinearLayoutManager(this)
        recyclerView.layoutManager = layoutManager
        /* getting main posts
            pageStart = 0
            postNumber = 5
            can be changed from utils.Constants
         */
        before(debut_page,nbr_page, 0)


        // infinite scroll
        recyclerView.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
                super.onScrollStateChanged(recyclerView, newState)
                if (!recyclerView.canScrollVertically(1)) {
                    if(!loading) {
                        // forward after reaching the button
                        before(debut_page,nbr_page*(call+1),3000)
                        // adding one callout
                        call++
                    }
                }
            }
        })

    }


    // forward ini
    private fun before(pageNumber: Int, postsNumber: Int, delay: Long) {
        // ini repository.Repository
        loading = true
        val repository = Poste_Repository()

        // ini viewModelFactory
        val viewModelFactory = MainViewModelFactory(repository)

        // forwading
        viewModel = ViewModelProvider(this, viewModelFactory).get(MainViewModel::class.java)
        viewModel.AfficherPosts(pageNumber, postsNumber)
        viewModel.responseData.observe(this, Observer { response ->
            if(response.isSuccessful){
                // delay to stop spam
                @Suppress("DEPRECATION")
                Handler().postDelayed({
                    loading = false
                }, delay)
                myAdapter.setData(this,R.layout.row_layout, response.body()?.data!!)
            }else {
                Toast.makeText(this, response.code(), Toast.LENGTH_SHORT).show()
            }
        })

    }

    //setting up recyclerview
    private fun setupRecyclerview() {
        recyclerView.adapter = myAdapter
        recyclerView.layoutManager = LinearLayoutManager(this)
    }


}











































